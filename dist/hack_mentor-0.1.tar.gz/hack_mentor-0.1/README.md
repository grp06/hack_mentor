# Hack Mentor

## Description

Hack Mentor is a command line tool that's like a mentor, for when you wanna hack.
